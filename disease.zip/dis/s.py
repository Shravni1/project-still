from flask import Flask, render_template, request, jsonify
import pandas as pd
import requests

app = Flask(__name__)

# Load and preprocess the dataset
try:
    disease_df = pd.read_csv("static/disease_main.csv")
    disease_df.columns = disease_df.columns.str.strip()  # Remove whitespace from column names
except Exception as e:
    print(f"Error loading dataset: {e}")
    disease_df = pd.DataFrame()

def fetch_disease_image(disease_name):
    try:
        url = "https://commons.wikimedia.org/w/api.php"
        params = {
            "action": "query",
            "format": "json",
            "prop": "imageinfo",
            "generator": "search",
            "gsrsearch": f"File:{disease_name} illustration",
            "iiprop": "url",
            "gsrlimit": 1,
        }
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        pages = data.get("query", {}).get("pages", {})
        for page in pages.values():
            if "imageinfo" in page:
                return page["imageinfo"][0]["url"]
    except requests.exceptions.RequestException as e:
        print(f"Wikimedia Commons API error: {e}")
    return "https://via.placeholder.com/600x400"  # Fallback image


@app.route('/')
def index():
    try:
        return render_template('dise.html')  # Load main page with letter-based navigation
    except Exception as e:
        return f"Error rendering index page: {e}", 500

@app.route('/api/diseases_by_letter')
def diseases_by_letter():
    try:
        # Get the letter from the query parameter
        letter = request.args.get('letter', '').upper()
        if not letter or len(letter) != 1:
            return jsonify([])

        # Filter diseases starting with the specified letter
        filtered = disease_df[disease_df['Disease Name'].str.startswith(letter, na=False)]
        return jsonify(filtered['Disease Name'].tolist())
    except KeyError:
        return jsonify([])

@app.route('/api/search')
def search_diseases():
    try:
        # Get the query from the user input
        query = request.args.get('query', '').lower().strip()
        if not query:
            return jsonify([])

        # Split the query into individual keywords (symptoms)
        query_keywords = query.split()

        # Find diseases whose symptoms contain any of the keywords
        disease_matches = []
        for _, row in disease_df.iterrows():
            symptoms = str(row['Symptoms']).lower()  # Ensure symptoms are string and lowercase
            match_count = sum(1 for keyword in query_keywords if keyword in symptoms)

            if match_count > 0:
                disease_matches.append({
                    "Disease Name": row['Disease Name'],
                    "Match Count": match_count
                })

        # Sort diseases by the number of matching symptoms (descending order)
        sorted_matches = sorted(disease_matches, key=lambda x: x['Match Count'], reverse=True)

        # Limit the results to the top 5 most relevant matches
        top_5_matches = sorted_matches[:5]

        # Return only the disease names in sorted order
        return jsonify([match['Disease Name'] for match in top_5_matches])

    except KeyError as e:
        print(f"Error: {e}")
        return jsonify([])  # Return an empty list if there's an issue

@app.route('/info/<disease_name>')
def disease_info(disease_name):
    try:
        # Find the specific disease from the dataset
        disease = disease_df[disease_df['Disease Name'] == disease_name].iloc[0]
        
        # Fetch disease image from Google Custom Search API
        image_url = fetch_disease_image(disease_name)
        
        return render_template('info.html', disease=disease.to_dict(), image_url=image_url)
    except IndexError:
        return "Disease not found.", 404

if __name__ == '__main__':
    app.run(debug=True)
