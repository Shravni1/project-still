from flask import Flask, render_template, request, jsonify,redirect, url_for
import pandas as pd
import re

app = Flask(__name__)

# Load and preprocess the dataset
try:
    disease_df = pd.read_csv("static/disease_main.csv")
    disease_df.columns = disease_df.columns.str.strip()  # Remove whitespace from column names
except Exception as e:
    print(f"Error loading dataset: {e}")
    disease_df = pd.DataFrame()

@app.route('/')
def index():
    # This will automatically redirect to the disease-based diet page
    return redirect(url_for('disease_based_diet'))

# Route for the disease-based diet page
@app.route('/disease-based-diet')
def disease_based_diet():
    try:
        return render_template('dise.html')  # Render the disease-based diet page
    except Exception as e:
        return f"Error rendering disease-based diet page: {e}", 500

@app.route('/api/diseases_by_letter')
def diseases_by_letter():
    try:
        # Get the letter from the query parameter
        letter = request.args.get('letter', '').upper()
        if not letter or len(letter) != 1:
            return jsonify([])

        # Filter diseases starting with the specified letter
        filtered = disease_df[disease_df['Disease Name'].str.startswith(letter, na=False)]
        return jsonify(filtered['Disease Name'].tolist())
    except KeyError:
        return jsonify([])

    

@app.route('/api/search')
def search_diseases():
    try:
        # Get the query from the user input
        query = request.args.get('query', '').lower().strip()
        if not query:
            return jsonify([])

        # Split the query into individual keywords (symptoms)
        query_keywords = query.split()

        # Find diseases whose symptoms contain any of the keywords
        disease_matches = []
        for _, row in disease_df.iterrows():
            symptoms = str(row['Symptoms']).lower()  # Ensure symptoms are string and lowercase
            match_count = sum(1 for keyword in query_keywords if keyword in symptoms)

            if match_count > 0:
                disease_matches.append({
                    "Disease Name": row['Disease Name'],
                    "Match Count": match_count
                })

        # Sort diseases by the number of matching symptoms (descending order)
        sorted_matches = sorted(disease_matches, key=lambda x: x['Match Count'], reverse=True)

        # Limit the results to the top 5 most relevant matches
        top_5_matches = sorted_matches[:5]

        # Return only the disease names in sorted order
        return jsonify([match['Disease Name'] for match in top_5_matches])

    except KeyError as e:
        print(f"Error: {e}")
        return jsonify([])  # Return an empty list if there's an issue

@app.route('/info/<disease_name>')
def disease_info(disease_name):
    try:
        # Fetch the disease row
        disease_row = disease_df[disease_df['Disease Name'] == disease_name]
        if disease_row.empty:
            return "Disease not found.", 404

        disease = disease_row.iloc[0].to_dict()

        # Ensure fields are strings before processing
        symptoms = str(disease.get('Symptoms', ''))
        causes = str(disease.get('Causes', ''))
        precautions = str(disease.get('Precautions', ''))
        recommended_foods = str(disease.get('Recommended Foods', ''))
        foods_to_avoid = str(disease.get('Foods to Avoid', ''))

        # Process data fields into lists
        import re
        symptoms = re.split(r'(?<=\w)\s*(?=[A-Z])|(?<=\n)\s*(?=[A-Z])', symptoms)
        symptoms = [s.strip() for s in symptoms if s.strip()]

        causes = re.split(r'(?<=\w)\s*(?=[A-Z])|(?<=\n)\s*(?=[A-Z])', causes)
        causes = [c.strip() for c in causes if c.strip()]

        precautions = re.split(r'(?<=\w)\s*(?=[A-Z])|(?<=\n)\s*(?=[A-Z])', precautions)
        precautions = [p.strip() for p in precautions if p.strip()]

        # Process recommended foods and foods to avoid as lists
        recommended_foods = re.split(r'(?<=\w)\s*(?=[A-Z])|(?<=\n)\s*(?=[A-Z])', recommended_foods)
        recommended_foods = [food.strip() for food in recommended_foods if food.strip()]

        foods_to_avoid = re.split(r'(?<=\w)\s*(?=[A-Z])|(?<=\n)\s*(?=[A-Z])', foods_to_avoid)
        foods_to_avoid = [food.strip() for food in foods_to_avoid if food.strip()]
        
        

        

                # Fetch meal plan
        meal_plan = disease.get('Sample Meal Plan', '')

        # Parse meal plan into a structured list of dictionaries
        day_plans = []
        try:
            if meal_plan:
                # Split the meal plan into days using "Day X:" as a delimiter
                days = re.split(r'Day \d+:\s*', meal_plan)
                for day_num, day_content in enumerate(days[1:], start=1):  # Skip the first empty split
                    # Split each day's content into meal items
                    meals = [line.strip() for line in day_content.split('\n') if line.strip()]
                    meals_dict = {}
                    for meal in meals:
                        if ':' in meal:  # Ensure the line contains a meal title and description
                            title, description = meal.split(':', 1)
                            meals_dict[title.strip()] = description.strip()
                    
                    # Add the day's details to the list
                    day_plans.append({"day": f"Day {day_num}", "meals": meals_dict})
        except Exception as parse_error:
            print(f"Error parsing meal plan: {parse_error}")

        # Fetch image URL with a default fallback
        image_url = disease.get('Images', 'https://via.placeholder.com/600x400')

        # Render the template with all the disease details
        return render_template(
            'info.html',
            disease=disease,
            symptoms=symptoms,
            causes=causes,
            precautions=precautions,
            recommended_foods=recommended_foods,
            foods_to_avoid=foods_to_avoid,
            meal_plan=day_plans,
            image_url=image_url
        )
    except Exception as e:
        return f"Error fetching disease info: {e}", 500

   





if __name__ == '__main__':
    # Specify the host and port
    # For example, change the host to '0.0.0.0' and port to 8000
    app.run(debug=True, host='0.0.0.0', port=8000)
