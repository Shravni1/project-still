// script.js
document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('.generate-button').addEventListener('click', (e) => {
      e.preventDefault();
      alert('Recipe Generated!');
    });
  });
  let selectedPrepTime = '';
let selectedServingCount = '';


function selectPrepTime(button, time) {
    // Remove highlight from all buttons
    const buttons = document.querySelectorAll('.prep-time-btn');
    buttons.forEach(btn => {
        btn.classList.remove('bg-[#447B66]', 'text-white');
        btn.classList.add('border');
    });

    // Highlight the selected button
    button.classList.add('bg-[#447B66]', 'text-white');
    button.classList.remove('border');

    selectedPrepTime = time; // Store the selected prep time
}

function selectServingCount(button, count) {
    // Remove highlight from all buttons
    const buttons = document.querySelectorAll('.serving-count-btn');
    buttons.forEach(btn => {
        btn.classList.remove('bg-[#447B66]', 'text-white');
        btn.classList.add('border');
    });

    // Highlight the selected button
    button.classList.add('bg-[#447B66]', 'text-white');
    button.classList.remove('border');

    selectedServingCount = count; // Store the selected serving count
}


async function generateRecipe() {
    // Gather selected values from the UI
    const cuisine = document.querySelector('#cuisine-select');  // Updated to match the id in HTML
    const mealType = document.querySelector('#meal-type-select');  // Updated to match the id in HTML
    const difficulty = document.querySelector('#difficulty-select');  // Updated to match the id in HTML


    
    const unwantedIngredients = []; // Populate this based on user input

    const response = await fetch('http://localhost:5000/generate-recipe', {
        method: 'POST',  // POST request
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            cuisine: cuisine,
            meal_type: mealType,
            difficulty: difficulty,
            unwanted_ingredients: unwantedIngredients,
            prep_time: selectedPrepTime,
            serving_count: selectedServingCount
        })
    });

    if (response.ok) {
        const data = await response.json();
        console.log(data);  // Handle the recipe data
        // You can update the UI to display the recipe
    } else {
        console.error('Error fetching recipe:', response.statusText);
        // Handle the error
    }
}

    

