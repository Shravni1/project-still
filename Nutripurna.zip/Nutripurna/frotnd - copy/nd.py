import os
import pandas as pd
import requests
from flask import Flask, request, jsonify, render_template
from gtts import gTTS

app = Flask(__name__)

# Load the dataset
try:
    recipes_df = pd.read_csv("static/archanas_kitchenmain.csv", encoding="utf-8")
    print("Dataset loaded successfully!")
except FileNotFoundError:
    print("Error: CSV file not found. Ensure 'archanas_kitchenmain.csv' is in the correct directory.")
    recipes_df = pd.DataFrame()
except Exception as e:
    print(f"Error loading CSV file: {e}")
    recipes_df = pd.DataFrame()

# Ensure required columns are present
required_columns = {"RecipeName", "Ingredients", "PrepTimeInMins", "Servings", "Cuisine", "Course", "Diet", "Instructions"}
if not required_columns.issubset(recipes_df.columns):
    print("Error: Dataset is missing required columns.")
    recipes_df = pd.DataFrame()

# Replace with your Google API key and Search Engine ID
GOOGLE_API_KEY = "AIzaSyCA_SC4gD650bCkWS62-3nkUt93WMhA8iQ"  # Add your API key here
SEARCH_ENGINE_ID = "27c7886149ae846a8"  # Add your Search Engine ID here

# General ingredient tips for common ingredients
common_ingredient_tips = {
    "chicken": "Always wash chicken thoroughly before cooking. Marinate for at least 30 minutes for better flavor.",
    "tomato": "Tomatoes are best used when slightly ripe; roasting them enhances their flavor.",
    "garlic": "Garlic can be crushed or minced, depending on the flavor intensity you want. Be cautious, as it burns easily.",
    "onion": "Onions should be sautéed until golden to bring out their natural sweetness.",
    "spinach": "Spinach wilts quickly, so add it last to preserve nutrients and color.",
    "potato": "Always wash and scrub potatoes thoroughly before cooking. You can peel or leave the skin on depending on your dish.",
    "paneer": "Paneer is best when fried or grilled for a crispy texture. Marinate before cooking for enhanced flavor.",
    "carrot": "Carrots can be roasted, boiled, or grated, depending on the dish. Make sure to wash them well.",
    "peas": "Peas cook quickly, so add them towards the end of the cooking process to preserve their color and sweetness.",
    "turmeric": "Turmeric stains, so be careful when handling it. It also pairs well with black pepper for better absorption.",
    "ginger": "Fresh ginger is great for adding warmth to dishes, while dried ginger adds more heat.",
    "lentils": "Rinse lentils thoroughly before cooking to remove any dust or impurities.",
    "coriander": "Coriander adds a fresh, citrusy note. Fresh leaves are best used as a garnish.",
    "chili": "Adjust the quantity of chili based on your preferred spice level. Fresh chilies can be used for a milder heat, while dried chilies provide a sharper spice."
}
# Edamam API credentials
EDAMAM_APP_ID = "d757d1f4"
EDAMAM_API_KEY = "23b5c8db99e2e479bf3a5258a563e3d4	"

# Function to normalize and clean ingredients (ingredient matching)
def normalize_ingredients(ingredients):
    # Clean and standardize ingredients (remove extra spaces, punctuation)
    ingredients = [re.sub(r'[^\w\s]', '', ingredient.strip().lower()) for ingredient in ingredients]
    return ingredients

# Function to fetch nutritional info from Edamam API
def fetch_nutrition_info(ingredients):
    try:
        url = "https://api.edamam.com/api/nutrition-details"
        headers = {"Content-Type": "application/json"}

        # Format ingredients for Edamam API
        formatted_ingredients = [{"quantity": 1, "measure": "item", "food": ingredient} for ingredient in ingredients]
        data = {"ingredients": formatted_ingredients}
        params = {"app_id": EDAMAM_APP_ID, "app_key": EDAMAM_API_KEY}

        response = requests.post(url, json=data, params=params, headers=headers)
        
        if response.status_code == 200:
            return response.json()  # Return the JSON data containing nutrition details
        else:
            print(f"Error fetching nutrition data: {response.status_code}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching nutritional data: {e}")
        return None

# Fetch recipe image from Google Custom Search
def fetch_recipe_image(recipe_name):
    try:
        url = f"https://www.googleapis.com/customsearch/v1"
        params = {
            "q": recipe_name,
            "cx": SEARCH_ENGINE_ID,
            "key": GOOGLE_API_KEY,
            "searchType": "image",
            "num": 1,
        }
        response = requests.get(url, params=params)
        response.raise_for_status()
        results = response.json().get("items", [])
        if results:
            return results[0]["link"]
    except Exception as e:
        print(f"Error fetching image for {recipe_name}: {e}")
    return "https://via.placeholder.com/300"  # Fallback image

import re

# Updated function for more flexible ingredient matching
def get_general_tips(ingredients):
    tips = []
    
    # Normalize ingredients: remove unwanted characters and convert to lowercase
    ingredients = [re.sub(r'[^\w\s]', '', ingredient.strip().lower()) for ingredient in ingredients]

    # Loop through each ingredient and check for a match with the common_ingredient_tips
    for ingredient in ingredients:
        for key in common_ingredient_tips.keys():
            # Check if the key (ingredient) is part of the ingredient list (using "in" for partial match)
            if key in ingredient:
                tips.append(common_ingredient_tips[key])
                break  # Stop after the first match for that ingredient to avoid duplicates

    return tips



import requests

# Function to fetch nutritional info from Edamam API
def fetch_nutrition_info(ingredients):
    try:
        url = "https://api.edamam.com/api/nutrition-details"
        headers = {"Content-Type": "application/json"}

        # Format ingredients for Edamam API
        formatted_ingredients = [{"quantity": 1, "measure": "item", "food": ingredient} for ingredient in ingredients]
        data = {"ingredients": formatted_ingredients}
        params = {"app_id": EDAMAM_APP_ID, "app_key": EDAMAM_API_KEY}

        response = requests.post(url, json=data, params=params, headers=headers)
        
        if response.status_code == 200:
            return response.json()  # Return the JSON data containing nutrition details
        else:
            print(f"Error fetching nutrition data: {response.status_code}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching nutritional data: {e}")
        return None

@app.route("/generate", methods=["GET"])
def generate():
    if recipes_df.empty:
        return render_template("results.html", recipes=None)

    try:
        # Get filters from query parameters
        cuisine = request.args.get("cuisine", "").strip().lower()
        meal_type = request.args.get("meal_type", "").strip().lower()
        prep_time = request.args.get("prep_time", type=int)
        servings = request.args.get("servings", type=int)
        ingredients = request.args.get("ingredients", "").strip().lower().split(",")
        unwanted_ingredients = request.args.get("unwanted_ingredients", "").strip().lower().split(",")
        diet = request.args.get("diet", "").strip().lower()

        # Apply filters
        filtered_recipes = recipes_df.copy()
        if cuisine:
            filtered_recipes = filtered_recipes[filtered_recipes["Cuisine"].str.lower() == cuisine]
        if meal_type:
            filtered_recipes = filtered_recipes[filtered_recipes["Course"].str.lower() == meal_type]
        if prep_time:
            filtered_recipes = filtered_recipes[filtered_recipes["PrepTimeInMins"] <= prep_time]
        if servings:
            filtered_recipes = filtered_recipes[filtered_recipes["Servings"] == servings]
        if diet:
            filtered_recipes = filtered_recipes[filtered_recipes["Diet"].str.lower() == diet]
        if ingredients and ingredients[0]:
            filtered_recipes = filtered_recipes[filtered_recipes["Ingredients"].str.lower().apply(
                lambda x: all(ingredient in x for ingredient in ingredients))]

        if unwanted_ingredients and unwanted_ingredients[0]:
            filtered_recipes = filtered_recipes[~filtered_recipes["Ingredients"].str.lower().apply(
                lambda x: any(ingredient in x for ingredient in unwanted_ingredients))]

        # Add image URLs, nutrients, and tips
        recipes = filtered_recipes.to_dict(orient="records")
        for recipe in recipes:
            recipe["ImageURL"] = fetch_recipe_image(recipe["RecipeName"])
            ingredients = [ingredient.strip() for ingredient in recipe["Ingredients"].split(",")]
            recipe["Tips"] = get_general_tips(ingredients)

            # Fetch nutritional info using Edamam API
            nutrition_data = fetch_nutrition_info(ingredients)
            if nutrition_data:
                recipe["Nutrients"] = nutrition_data.get("totalNutrients", {})
            else:
                recipe["Nutrients"] = {}

            # Print the ingredients, tips, and nutritional info for debugging
            print(f"Ingredients for {recipe['RecipeName']}: {ingredients}")
            print(f"Tips for {recipe['RecipeName']}: {recipe['Tips']}")
            print(f"Nutrients for {recipe['RecipeName']}: {recipe['Nutrients']}")

        return render_template("results.html", recipes=recipes)
    except Exception as e:
        print(f"Error during recipe generation: {e}")
        return render_template("results.html", recipes=None)


@app.route("/")
def home():
    cuisines = recipes_df["Cuisine"].dropna().unique().tolist() if not recipes_df.empty else []
    courses = recipes_df["Course"].dropna().unique().tolist() if not recipes_df.empty else []
    diets = recipes_df["Diet"].dropna().unique().tolist() if not recipes_df.empty else []

    return render_template("index.html", cuisines=cuisines, courses=courses, diets=diets)

if __name__ == "__main__":
    app.run(debug=True)






# # HOME.HTML<!DOCTYPE html>
# <html>
# <head>
#     <title>Recipe Generator</title>
# </head>
# <body>
#     <h1>Recipe Generator</h1>
#     <form method="get" action="/">
#         <label for="cuisine">Cuisine:</label>
#         <input type="text" name="cuisine" id="cuisine" value="{{ request.args.get('cuisine', '') }}">
        
#         <label for="diet">Diet:</label>
#         <input type="text" name="diet" id="diet" value="{{ request.args.get('diet', '') }}">
        
#         <label for="max_prep_time">Max Prep Time (mins):</label>
#         <input type="number" name="max_prep_time" id="max_prep_time" value="{{ request.args.get('max_prep_time', '') }}">
        
#         <label for="ingredient">Ingredients (Optional):</label>
#         <input type="text" name="ingredient" id="ingredient" value="{{ request.args.get('ingredient', '') }}">
        
#         <button type="submit">Generate Recipe</button>
#     </form>

#     <h2>Filtered Recipes:</h2>
#     <ul>
#         {% for recipe in recipes %}
#             <li>
#                 <a href="/details?recipe_name={{ recipe['RecipeName'] }}">{{ recipe['RecipeName'] }}</a>
#                 ({{ recipe['Cuisine'] }} - {{ recipe['Diet'] }}, Prep Time: {{ recipe['PrepTimeInMins'] }} mins)
#             </li>
#         {% endfor %}
#     </ul>
# </body>
# </html>
# #

# # details.html
# <!DOCTYPE html>
# <html>
# <head>
#     <title>{{ recipe["RecipeName"] }} - Details</title>
# </head>
# <body>
#     <h1>{{ recipe["RecipeName"] }}</h1>
#     <h3>Cuisine: {{ recipe["Cuisine"] }}</h3>
#     <h3>Diet: {{ recipe["Diet"] }}</h3>
#     <h3>Prep Time: {{ recipe["PrepTimeInMins"] }} mins</h3>

#     <h2>Ingredients:</h2>
#     <ul>
#         {% for ingredient in recipe["ParsedIngredients"] %}
#             <li>
#                 {{ ingredient["Quantity"] }} {{ ingredient["Unit"] }} {{ ingredient["Ingredient"] }} 
#                 {% if ingredient["Notes"] %} - {{ ingredient["Notes"] }}{% endif %}
#             </li>
#         {% endfor %}
#     </ul>

#     <h2>Instructions:</h2>
#     <p>{{ recipe["Instructions"] }}</p>

#     <h2>Nutritional Information (Per Serving):</h2>
#     <ul>
#         <li>Calories: {{ recipe["Nutrients"]["Calories"] }} kcal</li>
#         <li>Protein: {{ recipe["Nutrients"]["Protein"] }} g</li>
#         <li>Fat: {{ recipe["Nutrients"]["Fat"] }} g</li>
#         <li>Carbohydrates: {{ recipe["Nutrients"]["Carbohydrates"] }} g</li>
#     </ul>
# </body>
# </html>
