from flask import Flask, render_template, request,redirect, url_for
import pandas as pd
import re
import requests

app = Flask(__name__)

# Load dataset
recipes_df = pd.read_csv("static/archanas_kitchenmain.csv")
# Ensure required columns are present
required_columns = {"RecipeName", "Ingredients", "PrepTimeInMins", "Servings", "Cuisine", "Course", "Diet", "Instructions"}
if not required_columns.issubset(recipes_df.columns):
    print("Error: Dataset is missing required columns.")
    recipes_df = pd.DataFrame()

import re

# Function to parse individual ingredient strings
def parse_ingredient(ingredient):
    """
    Parses an ingredient string to extract quantity, unit, ingredient name, and notes.
    
    Args:
        ingredient (str): The raw ingredient string.
    
    Returns:
        dict: A dictionary containing 'Quantity', 'Unit', 'Ingredient', and 'Notes'.
    """
    # List of words that should be treated as a specific quantity (e.g., "chopped", "diced", etc.)
    special_words = ["chopped", "diced", "minced", "sliced", "grated", "crushed", "peeled", "finely", "roasted"]

    # Check if any of the special words are in the ingredient string
    for word in special_words:
        if word in ingredient.lower():
            # If found, handle the ingredient with the special word
            parts = ingredient.strip().split(" ", 1)
            if len(parts) > 1:
                # For example, "1 chopped onion" becomes quantity = "1", ingredient = "onion"
                quantity = parts[0]
                name = parts[1].strip()
            else:
                quantity = "as needed"
                name = parts[0]
            
            return {
                "Quantity": quantity,
                "Unit": "unit",  # You can modify this if you want to handle specific units
                "Ingredient": name,
                "Notes": ""
            }
    
    # Regular expression to match quantity, unit, and ingredient details for other cases
    pattern = r"(?:(\d+(?:\.\d+)?(?:/\d+(?:\.\d+)?)?)(?:\s+|\s*-)?([a-zA-Z]+)?)?\s*(.*)"
    match = re.match(pattern, ingredient.strip())
    
    if match:
        # Extract quantity
        quantity = match.group(1) or "as needed"
        # Normalize unit
        unit = match.group(2).strip().lower() if match.group(2) else "unit"
        # Extract ingredient details and notes
        details = match.group(3).strip()
        if " - " in details:
            name, notes = map(str.strip, details.split(" - ", 1))
        else:
            name, notes = details, ""
        
        # Return parsed values
        return {
            "Quantity": quantity,
            "Unit": unit,
            "Ingredient": name,
            "Notes": notes
        }
    
    return {
        "Quantity": None,
        "Unit": None,
        "Ingredient": ingredient.strip(),
        "Notes": None
    }



def fetch_nutrition_info(ingredients):
    APP_ID = "aa40b5b0"  # Replace with your Edamam App ID
    APP_KEY = "8108454c758139f6c15e7468738d6e01"
    url = "https://api.edamam.com/api/nutrition-details"
    headers = {"Content-Type": "application/json"}
    payload = {"title": "Recipe Nutritional Info", "ingr": ingredients}
    try:
        response = requests.post(url, headers=headers, json=payload, params={"app_id": APP_ID, "app_key": APP_KEY})
        if response.status_code == 200:
            data = response.json()
            if 'calories' in data:
                return data
            else:
                print("Calories not found in the response.")
                return {"calories": "N/A"}  # Return N/A if calories are missing
        else:
            print(f"Error: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Nutrition API error: {e}")
    return {"calories": "N/A"}  # Return N/A if the API call fails

# Fetch recipe image from Google Custom Search API
def fetch_recipe_image(recipe_name):
    GOOGLE_API_KEY = "AIzaSyCA_SC4gD650bCkWS62-3nkUt93WMhA8iQ"  # Replace with your API key
    SEARCH_ENGINE_ID = "27c7886149ae846a8"  # Replace with your Search Engine ID
    try:
        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            "q": recipe_name,
            "cx": SEARCH_ENGINE_ID,
            "key": GOOGLE_API_KEY,
            "searchType": "image",
            "num": 1,
        }
        response = requests.get(url, params=params)
        response.raise_for_status()
        results = response.json().get("items", [])
        if results:
            return results[0]["link"]
    except requests.exceptions.RequestException as e:
        print(f"Image API error: {e}")
    return "https://via.placeholder.com/300"  # Fallback image

# Common ingredient tips
common_ingredient_tips = {
    "chicken": "Always wash chicken thoroughly before cooking. Marinate for at least 30 minutes for better flavor.",
    "tomato": "Tomatoes are best used when slightly ripe; roasting them enhances their flavor.",
    "garlic": "Garlic can be crushed or minced, depending on the flavor intensity you want. Be cautious, as it burns easily.",
    "onion": "Onions should be sautéed until golden to bring out their natural sweetness.",
    "spinach": "Spinach wilts quickly, so add it last to preserve nutrients and color.",
    "potato": "Always wash and scrub potatoes thoroughly before cooking. You can peel or leave the skin on depending on your dish.",
    "paneer": "Paneer is best when fried or grilled for a crispy texture. Marinate before cooking for enhanced flavor.",
    "carrot": "Carrots can be roasted, boiled, or grated, depending on the dish. Make sure to wash them well.",
    "peas": "Peas cook quickly, so add them towards the end of the cooking process to preserve their color and sweetness.",
    "turmeric": "Turmeric stains, so be careful when handling it. It also pairs well with black pepper for better absorption.",
    "ginger": "Fresh ginger is great for adding warmth to dishes, while dried ginger adds more heat.",
    "lentils": "Rinse lentils thoroughly before cooking to remove any dust or impurities.",
    "coriander": "Coriander adds a fresh, citrusy note. Fresh leaves are best used as a garnish.",
    "beetroot" :"Add a pinch of cinnamon or nutmeg to complement the earthy beet flavor.",
    "sugar" :"Use raw, unrefined sugar (e.g., coconut sugar or organic brown sugar) instead of white sugar for added nutrients and a rich flavor.",
    "chili": "Adjust the quantity of chili based on your preferred spice level. Fresh chilies can be used for a milder heat, while dried chilies provide a sharper spice.",
}

# Get general tips for ingredients
def get_general_tips(ingredients):
    tips = []
    normalized_ingredients = [re.sub(r'[^\w\s]', '', ingredient.strip().lower()) for ingredient in ingredients]
    for ingredient in normalized_ingredients:
        for key, tip in common_ingredient_tips.items():
            if key in ingredient:
                tips.append(f" {key}: {tip}")
                break
    return tips
@app.route("/<recipe_name>", methods=["GET"])
def recipe(recipe_name):
    # Convert the recipe name back to the proper format (e.g., spaces and case)
    recipe_name_original = recipe_name.replace("-", " ").title()

    # Fetch the recipe from the dataset based on RecipeName
    recipe = recipes_df[recipes_df["RecipeName"].str.lower() == recipe_name_original.lower()].iloc[0]

    # Extract the ingredients and other details
    ingredients_list = recipe["Ingredients"].split(",")
    parsed_ingredients = [parse_ingredient(ing) for ing in ingredients_list]
    nutrition_info = fetch_nutrition_info([f"{ing['Quantity']} {ing['Unit']} {ing['Ingredient']}" for ing in parsed_ingredients])
    image_url = fetch_recipe_image(recipe["RecipeName"])
    tips = get_general_tips(ingredients_list)

    return render_template(
        "details.html",
        recipe=recipe,
        parsed_ingredients=parsed_ingredients,
        nutrition_info=nutrition_info,
        image_url=image_url,
        tips=tips
    )

    



# Fetch recipe details
@app.route("/", methods=["GET", "POST"])
def home():
    # Dynamically fetch unique values for dropdown filters
    cuisines = sorted(recipes_df["Cuisine"].dropna().unique())
    diets = sorted(recipes_df["Diet"].dropna().unique())
    meal_types = sorted(recipes_df["Course"].dropna().unique())

    if request.method == "POST":
        # Get user inputs
        cuisine = request.form.get("cuisine", "").strip()
        diet = request.form.get("diet", "").strip()
        meal_type = request.form.get("meal_type", "").strip()

        # Start with the full dataset
        filtered_recipes = recipes_df

        # **Mandatory cuisine filter**
        if cuisine:
            filtered_recipes = filtered_recipes[filtered_recipes["Cuisine"].str.contains(cuisine, case=False, na=False)]
        else:
            # If no cuisine is selected, return an error message
            return render_template(
                "home.html",
                cuisines=cuisines,
                diets=diets,
                meal_types=meal_types,
                error="Cuisine selection is mandatory."
            )

        # Apply additional filters (diet and meal type)
        filtered_recipes_all = filtered_recipes  # Backup of the filtered recipes for all three parameters
        if diet:
            filtered_recipes = filtered_recipes[filtered_recipes["Diet"].str.contains(diet, case=False, na=False)]
        if meal_type:
            filtered_recipes = filtered_recipes[filtered_recipes["Course"].str.contains(meal_type, case=False, na=False)]

        # If no match with all three filters, fallback to any two filters
        if filtered_recipes.empty:
            filtered_recipes = filtered_recipes_all
            if diet:
                filtered_recipes = filtered_recipes[filtered_recipes["Diet"].str.contains(diet, case=False, na=False)]
            if meal_type and filtered_recipes.empty:
                filtered_recipes = filtered_recipes_all[
                    filtered_recipes_all["Course"].str.contains(meal_type, case=False, na=False)
                ]

        # If no recipe matches, select a random recipe from the original cuisine filter
        if filtered_recipes.empty:
            recipe = filtered_recipes_all.sample(1).iloc[0]
        else:
            recipe = filtered_recipes.sample(1).iloc[0]

        recipe_name = recipe['RecipeName'].replace(" ", "-").lower()  # Make the recipe name URL-friendly
        return redirect(url_for('recipe', recipe_name=recipe_name))

    return render_template(
        "home.html",
        cuisines=cuisines,
        diets=diets,
        meal_types=meal_types,
    )
if __name__ == "__main__":
    app.run(debug=True)





