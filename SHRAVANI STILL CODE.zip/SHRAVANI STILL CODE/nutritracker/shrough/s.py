from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import requests
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)

# Google Custom Search API configuration
GOOGLE_API_KEY = 'YOUR_GOOGLE_API_KEY'
CUSTOM_SEARCH_ENGINE_ID = 'YOUR_SEARCH_ENGINE_ID'
SEARCH_URL = 'https://www.googleapis.com/customsearch/v1'

def init_db():
    conn = sqlite3.connect('food_tracker.db')
    c = conn.cursor()
    
    # Create foods table
    c.execute('''
        CREATE TABLE IF NOT EXISTS foods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            serving_size TEXT NOT NULL,
            calories REAL NOT NULL,
            protein REAL NOT NULL,
            carbs REAL NOT NULL,
            fat REAL NOT NULL,
            source_url TEXT
        )
    ''')
    
    # Create meal_entries table
    c.execute('''
        CREATE TABLE IF NOT EXISTS meal_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            food_id INTEGER NOT NULL,
            meal_type TEXT NOT NULL,
            quantity REAL NOT NULL,
            date TEXT NOT NULL,
            FOREIGN KEY (food_id) REFERENCES foods (id)
        )
    ''')
    
    conn.commit()
    conn.close()

def get_db():
    conn = sqlite3.connect('food_tracker.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/api/search', methods=['GET'])
def search_food():
    query = request.args.get('q', '')
    conn = get_db()
    c = conn.cursor()
    
    # Search in local database
    c.execute('''
        SELECT * FROM foods 
        WHERE name LIKE ? 
        LIMIT 5
    ''', (f'%{query}%',))
    
    db_results = [dict(row) for row in c.fetchall()]
    
    # If we don't have enough results, search using Google API
    if len(db_results) < 5:
        try:
            params = {
                'key': GOOGLE_API_KEY,
                'cx': CUSTOM_SEARCH_ENGINE_ID,
                'q': f'{query} recipe nutrition facts',
                'num': 5 - len(db_results)
            }
            
            response = requests.get(SEARCH_URL, params=params)
            search_results = response.json().get('items', [])
            
            for result in search_results:
                title = result['title'].split('|')[0].strip()
                snippet = result['snippet']
                nutrition = extract_nutrition_from_snippet(snippet)
                
                if nutrition:
                    c.execute('''
                        INSERT INTO foods (name, serving_size, calories, protein, carbs, fat, source_url)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        title,
                        nutrition['serving_size'],
                        nutrition['calories'],
                        nutrition['protein'],
                        nutrition['carbs'],
                        nutrition['fat'],
                        result['link']
                    ))
                    
                    food_id = c.lastrowid
                    c.execute('SELECT * FROM foods WHERE id = ?', (food_id,))
                    new_food = dict(c.fetchone())
                    db_results.append(new_food)
            
            conn.commit()
        
        except Exception as e:
            print(f"Error searching Google API: {e}")
    
    conn.close()
    return jsonify(db_results)

@app.route('/api/meals', methods=['POST'])
def add_meal():
    data = request.json
    conn = get_db()
    c = conn.cursor()
    
    try:
        c.execute('''
            INSERT INTO meal_entries (food_id, meal_type, quantity, date)
            VALUES (?, ?, ?, ?)
        ''', (
            data['food_id'],
            data['meal_type'],
            data['quantity'],
            datetime.now().strftime('%Y-%m-%d')
        ))
        
        conn.commit()
        meal_id = c.lastrowid
        
        return jsonify({
            'message': 'Meal added successfully',
            'id': meal_id
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400
    
    finally:
        conn.close()

@app.route('/api/meals/<int:entry_id>', methods=['PUT'])
def update_meal(entry_id):
    data = request.json
    conn = get_db()
    c = conn.cursor()
    
    try:
        c.execute('''
            UPDATE meal_entries 
            SET quantity = ?
            WHERE id = ?
        ''', (data['quantity'], entry_id))
        
        conn.commit()
        
        if c.rowcount == 0:
            return jsonify({'error': 'Meal entry not found'}), 404
            
        return jsonify({'message': 'Meal updated successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400
    
    finally:
        conn.close()

@app.route('/api/meals/<int:entry_id>', methods=['DELETE'])
def delete_meal(entry_id):
    conn = get_db()
    c = conn.cursor()
    
    try:
        c.execute('DELETE FROM meal_entries WHERE id = ?', (entry_id,))
        conn.commit()
        
        if c.rowcount == 0:
            return jsonify({'error': 'Meal entry not found'}), 404
            
        return jsonify({'message': 'Meal deleted successfully'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400
    
    finally:
        conn.close()

@app.route('/api/meals/daily', methods=['GET'])
def get_daily_meals():
    date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    conn = get_db()
    c = conn.cursor()
    
    try:
        c.execute('''
            SELECT 
                me.id as entry_id,
                me.meal_type,
                me.quantity,
                f.*
            FROM meal_entries me
            JOIN foods f ON me.food_id = f.id
            WHERE me.date = ?
        ''', (date,))
        
        entries = [dict(row) for row in c.fetchall()]
        meals = {}
        
        for entry in entries:
            meal_type = entry['meal_type']
            meal_data = {
                'id': entry['entry_id'],
                'food': {
                    'id': entry['id'],
                    'name': entry['name'],
                    'serving': entry['serving_size'],
                    'calories': entry['calories'],
                    'protein': entry['protein'],
                    'carbs': entry['carbs'],
                    'fat': entry['fat']
                },
                'quantity': entry['quantity']
            }
            
            if meal_type not in meals:
                meals[meal_type] = []
            meals[meal_type].append(meal_data)
        
        return jsonify(meals)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400
    
    finally:
        conn.close()

def extract_nutrition_from_snippet(snippet):
    """
    Helper function to extract nutrition information from search result snippets.
    This is a simplified version - you'd want more sophisticated parsing in production.
    """
    try:
        # Extract calories - looking for numbers followed by "calories"
        import re
        calories_match = re.search(r'(\d+)\s*calories', snippet.lower())
        calories = float(calories_match.group(1)) if calories_match else 300
        
        # Generate reasonable defaults based on calories
        return {
            'serving_size': '1 serving',
            'calories': calories,
            'protein': calories * 0.15 / 4,  # 15% of calories from protein
            'carbs': calories * 0.50 / 4,    # 50% of calories from carbs
            'fat': calories * 0.35 / 9       # 35% of calories from fat
        }
    except:
        return None

@app.before_first_request
def setup():
    init_db()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)