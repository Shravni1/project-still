from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import requests

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///meal_tracker.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

class Meal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    food_item = db.Column(db.String(200), nullable=False)
    calories = db.Column(db.Float, nullable=False)
    protein = db.Column(db.Float, nullable=False)
    carbohydrates = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, default=datetime.utcnow)

with app.app_context():
    db.create_all()

API_KEY = 'd5720713e7c975d5313bddf77eda13be'
APP_ID ='44b87180'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search_food', methods=['GET'])
def search_food():
    query = request.args.get('query')
    url = f'https://api.edamam.com/api/food-database/v2/parser?ingr={query}&app_id=YOUR_APP_ID&app_key={API_KEY}'
    response = requests.get(url)
    if response.status_code == 200:
        return jsonify(response.json())
    return jsonify({'error': 'Failed to fetch food data'}), 400

@app.route('/add_meal', methods=['POST'])
def add_meal():
    data = request.json
    try:
        meal = Meal(
            user_id=data['user_id'],
            food_item=data['food_item'],
            calories=data['calories'],
            protein=data['protein'],
            carbohydrates=data['carbohydrates'],
            date=datetime.strptime(data['date'], '%Y-%m-%d').date()
        )
        db.session.add(meal)
        db.session.commit()
        return jsonify({'message': 'Meal added successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/get_meals/<int:user_id>', methods=['GET'])
def get_daily_meals(user_id):
    date_str = request.args.get('date', datetime.utcnow().strftime('%Y-%m-%d'))
    date = datetime.strptime(date_str, '%Y-%m-%d').date()
    meals = Meal.query.filter_by(user_id=user_id, date=date).all()
    result = [{
        'food_item': meal.food_item,
        'calories': meal.calories,
        'protein': meal.protein,
        'carbohydrates': meal.carbohydrates
    } for meal in meals]
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
