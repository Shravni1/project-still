from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
import requests
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///food_tracker.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Google Custom Search API configuration
GOOGLE_API_KEY = 'AIzaSyC7FzvNrh327o2B2EC89eUJ4ZMIPtbv8-Y'
CUSTOM_SEARCH_ENGINE_ID = '7275af6fee0934ffa'
SEARCH_URL = 'https://www.googleapis.com/customsearch/v1'

db = SQLAlchemy(app)

# Database Models
class Food(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    serving_size = db.Column(db.String(50), nullable=False)
    calories = db.Column(db.Float, nullable=False)
    protein = db.Column(db.Float, nullable=False)
    carbs = db.Column(db.Float, nullable=False)
    fat = db.Column(db.Float, nullable=False)
    source_url = db.Column(db.String(200))

class MealEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    food_id = db.Column(db.Integer, db.ForeignKey('food.id'), nullable=False)
    meal_type = db.Column(db.String(20), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, nullable=False)
    
    food = db.relationship('Food', backref='meal_entries')

@app.route('/api/search', methods=['GET'])
def search_food():
    query = request.args.get('q', '')
    
    # First check our database
    db_results = Food.query.filter(Food.name.ilike(f'%{query}%')).limit(5).all()
    
    # If we don't have enough results, search using Google API
    if len(db_results) < 5:
        try:
            # Search for recipes using Google Custom Search
            params = {
                'key': GOOGLE_API_KEY,
                'cx': CUSTOM_SEARCH_ENGINE_ID,
                'q': f'{query} recipe nutrition facts',
                'num': 5 - len(db_results)
            }
            
            response = requests.get(SEARCH_URL, params=params)
            search_results = response.json().get('items', [])
            
            # Process search results and extract nutrition information
            for result in search_results:
                # Basic nutrition extraction (you'd want to improve this with better parsing)
                title = result['title'].split('|')[0].strip()
                snippet = result['snippet']
                
                # Extract nutrition info from snippet or fetch from result['link']
                # This is a simplified example - you'd want more robust parsing
                nutrition = extract_nutrition_from_snippet(snippet)
                
                # Save to database if we found nutrition info
                if nutrition:
                    new_food = Food(
                        name=title,
                        serving_size=nutrition['serving_size'],
                        calories=nutrition['calories'],
                        protein=nutrition['protein'],
                        carbs=nutrition['carbs'],
                        fat=nutrition['fat'],
                        source_url=result['link']
                    )
                    db.session.add(new_food)
                    db.session.commit()
                    db_results.append(new_food)
        
        except Exception as e:
            print(f"Error searching Google API: {e}")
    
    # Format results
    results = [{
        'id': food.id,
        'name': food.name,
        'serving': food.serving_size,
        'calories': food.calories,
        'protein': food.protein,
        'carbs': food.carbs,
        'fat': food.fat,
        'source_url': food.source_url
    } for food in db_results]
    
    return jsonify(results)
import re

def extract_nutrition_from_snippet(snippet):
    """ Extracts nutrition data from a snippet using regex. """
    try:
        calories = re.search(r'(\d+)\s*calories', snippet)
        protein = re.search(r'(\d+)\s*g protein', snippet)
        carbs = re.search(r'(\d+)\s*g carbs', snippet)
        fat = re.search(r'(\d+)\s*g fat', snippet)

        return {
            'serving_size': '1 serving',
            'calories': float(calories.group(1)) if calories else 0,
            'protein': float(protein.group(1)) if protein else 0,
            'carbs': float(carbs.group(1)) if carbs else 0,
            'fat': float(fat.group(1)) if fat else 0
        }
    except:
        return None
@app.route('/api/meals/summary', methods=['GET'])
def daily_nutrition_summary():
    date = request.args.get('date', datetime.now().date())

    entries = MealEntry.query.filter_by(date=date).all()
    
    summary = {'calories': 0, 'protein': 0, 'carbs': 0, 'fat': 0}

    for entry in entries:
        summary['calories'] += entry.food.calories * entry.quantity
        summary['protein'] += entry.food.protein * entry.quantity
        summary['carbs'] += entry.food.carbs * entry.quantity
        summary['fat'] += entry.food.fat * entry.quantity

    return jsonify(summary)


@app.route('/api/meals', methods=['POST'])
def add_meal():
    data = request.json
    
    new_entry = MealEntry(
        food_id=data['food_id'],
        meal_type=data['meal_type'],
        quantity=data['quantity'],
        date=datetime.now().date()
    )
    
    db.session.add(new_entry)
    db.session.commit()
    
    return jsonify({'message': 'Meal added successfully'})

@app.route('/api/meals/<int:entry_id>', methods=['PUT'])
def update_meal(entry_id):
    entry = MealEntry.query.get_or_404(entry_id)
    data = request.json
    
    entry.quantity = data.get('quantity', entry.quantity)
    db.session.commit()
    
    return jsonify({'message': 'Meal updated successfully'})

@app.route('/api/meals/<int:entry_id>', methods=['DELETE'])
def delete_meal(entry_id):
    entry = MealEntry.query.get_or_404(entry_id)
    db.session.delete(entry)
    db.session.commit()
    
    return jsonify({'message': 'Meal deleted successfully'})

@app.route('/api/meals/daily', methods=['GET'])
def get_daily_meals():
    date = request.args.get('date', datetime.now().date())
    
    entries = MealEntry.query.filter_by(date=date).all()
    meals = {}
    
    for entry in entries:
        meal_data = {
            'id': entry.id,
            'food': {
                'id': entry.food.id,
                'name': entry.food.name,
                'serving': entry.food.serving_size,
                'calories': entry.food.calories,
                'protein': entry.food.protein,
                'carbs': entry.food.carbs,
                'fat': entry.food.fat
            },
            'quantity': entry.quantity
        }
        
        if entry.meal_type not in meals:
            meals[entry.meal_type] = []
        meals[entry.meal_type].append(meal_data)
    
    return jsonify(meals)

def extract_nutrition_from_snippet(snippet):
    """
    Helper function to extract nutrition information from search result snippets.
    You'd want to implement more sophisticated parsing here.
    """
    try:
        # This is a very simplified example - you'd want more robust parsing
        return {
            'serving_size': '1 serving',
            'calories': float(snippet.split('calories')[0].split()[-1]),
            'protein': 10.0,  # Default values - you'd want to extract these
            'carbs': 30.0,    # from the actual content
            'fat': 5.0
        }
    except:
        return None

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)