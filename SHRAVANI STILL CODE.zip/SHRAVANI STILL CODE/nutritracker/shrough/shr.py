from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import sqlite3
import requests

app = Flask(__name__)
CORS(app)

# Database setup
def init_db():
    conn = sqlite3.connect('nutrition.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS meals (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        meal_type TEXT,
                        food_name TEXT,
                        calories REAL,
                        protein REAL,
                        carbs REAL,
                        fats REAL,
                        serving_size REAL
                     )''')
    conn.commit()
    conn.close()

init_db()

# Google Gemini API Configuration
GEMINI_API_KEY = "AIzaSyC6U1zg9ff_B23Ui9Fpm07NMVLJLKrhICE"

def search_recipes(query):
    """Fetch recipes dynamically based on user input."""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateText?key={GEMINI_API_KEY}"
    
    headers = {"Content-Type": "application/json"}
    payload = {
        "prompt": {
            "text": f"Suggest 5 recipes that start with '{query}'. Include the recipe name, ingredients, and short instructions."
        },
        "max_tokens": 300
    }

    response = requests.post(url, json=payload, headers=headers)
    data = response.json()

    try:
        recipes = data['candidates'][0]['output'].split("\n\n")  # Splitting multiple results
        return {"recipes": recipes}
    except KeyError:
        return {"error": "No recipes found. Try another search."}

# API Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search_recipes', methods=['GET'])
def search_recipes_route():
    """Handles recipe search based on user input."""
    query = request.args.get('query', '')
    if not query:
        return jsonify({"error": "Query cannot be empty."})
    
    results = search_recipes(query)
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
