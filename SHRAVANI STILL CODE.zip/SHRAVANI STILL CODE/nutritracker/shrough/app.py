# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import requests
from datetime import datetime

app = Flask(__name__)
CORS(app)

# API Keys (In production, these should be environment variables)
GOOGLE_API_KEY = 'AIzaSyC7FzvNrh327o2B2EC89eUJ4ZMIPtbv8-Y"'
GOOGLE_CSE_ID = '7275af6fee0934ffa'
SPOONACULAR_API_KEY = 'c48f2c2d1c97473fb5dd88c7ec129034'

# Database initialization
def init_db():
    conn = sqlite3.connect('food_tracker.db')
    c = conn.cursor()
    
    # Create foods table
    c.execute('''
        CREATE TABLE IF NOT EXISTS foods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            serving_size TEXT,
            calories REAL,
            protein REAL,
            carbs REAL,
            fat REAL,
            source_api TEXT,
            api_id TEXT
        )
    ''')
    
    # Create meal_entries table
    c.execute('''
        CREATE TABLE IF NOT EXISTS meal_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            food_id INTEGER,
            meal_type TEXT,
            quantity REAL,
            date TEXT,
            FOREIGN KEY (food_id) REFERENCES foods (id)
        )
    ''')
    
    conn.commit()
    conn.close()

init_db()

def get_db():
    conn = sqlite3.connect('food_tracker.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/api/search', methods=['GET'])
def search_foods():
    query = request.args.get('q', '')
    
    # First check our database
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM foods WHERE name LIKE ? LIMIT 5", (f'%{query}%',))
    db_results = [dict(row) for row in c.fetchall()]
    conn.close()
    
    # If we have fewer than 5 results, search external APIs
    if len(db_results) < 5:
        # Search Spoonacular
        spoonacular_results = search_spoonacular(query)
        
        # Search Google Custom Search for recipes
        google_results = search_google_recipes(query)
        
        # Combine and deduplicate results
        all_results = process_and_combine_results(db_results, spoonacular_results, google_results)
        return jsonify(all_results)
    
    return jsonify([format_food(food) for food in db_results])

def search_spoonacular(query):
    url = 'https://api.spoonacular.com/food/ingredients/search'
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'query': query,
        'number': 5,
        'addChildren': True
    }
    
    try:
        response = requests.get(url, params=params)
        if response.status_code == 200:
            results = response.json().get('results', [])
            detailed_results = []
            
            for result in results:
                nutrition = get_spoonacular_nutrition(result['id'])
                if nutrition:
                    detailed_results.append({
                        'source_api': 'spoonacular',
                        'api_id': str(result['id']),
                        'name': result['name'],
                        'serving_size': '100g',
                        **nutrition
                    })
            
            return detailed_results
    except Exception as e:
        print(f"Spoonacular API error: {e}")
    return []

def get_spoonacular_nutrition(ingredient_id):
    url = f'https://api.spoonacular.com/food/ingredients/{ingredient_id}/information'
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'amount': 100,
        'unit': 'g'
    }
    
    try:
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            nutrients = data.get('nutrition', {}).get('nutrients', [])
            
            nutrition = {
                'calories': 0,
                'protein': 0,
                'carbs': 0,
                'fat': 0
            }
            
            for nutrient in nutrients:
                if nutrient['name'] == 'Calories':
                    nutrition['calories'] = nutrient['amount']
                elif nutrient['name'] == 'Protein':
                    nutrition['protein'] = nutrient['amount']
                elif nutrient['name'] == 'Carbohydrates':
                    nutrition['carbs'] = nutrient['amount']
                elif nutrient['name'] == 'Fat':
                    nutrition['fat'] = nutrient['amount']
                    
            return nutrition
    except Exception as e:
        print(f"Spoonacular nutrition API error: {e}")
    return None

def search_google_recipes(query):
    url = 'https://www.googleapis.com/customsearch/v1'
    params = {
        'key': GOOGLE_API_KEY,
        'cx': GOOGLE_CSE_ID,
        'q': f'recipe {query} nutrition facts',
        'num': 5
    }
    
    try:
        response = requests.get(url, params=params)
        if response.status_code == 200:
            results = response.json().get('items', [])
            return [{
                'source_api': 'google',
                'api_id': item['link'],
                'name': item['title'].replace(' - Recipe', '').replace(' Recipe', ''),
                'serving_size': 'serving',
                'url': item['link']
            } for item in results]
    except Exception as e:
        print(f"Google API error: {e}")
    return []

def process_and_combine_results(db_results, spoonacular_results, google_results):
    formatted_results = [format_food(food) for food in db_results]
    conn = get_db()
    c = conn.cursor()
    
    # Add new Spoonacular results
    for result in spoonacular_results:
        c.execute("SELECT id FROM foods WHERE source_api = ? AND api_id = ?",
                 ('spoonacular', result['api_id']))
        existing_food = c.fetchone()
        
        if not existing_food:
            c.execute("""
                INSERT INTO foods (name, serving_size, calories, protein, carbs, fat, source_api, api_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                result['name'],
                result['serving_size'],
                result.get('calories', 0),
                result.get('protein', 0),
                result.get('carbs', 0),
                result.get('fat', 0),
                'spoonacular',
                result['api_id']
            ))
            conn.commit()
            result['id'] = c.lastrowid
            formatted_results.append(format_food(result))
    
    # Process Google results
    for result in google_results:
        c.execute("SELECT id FROM foods WHERE source_api = ? AND api_id = ?",
                 ('google', result['api_id']))
        existing_food = c.fetchone()
        
        if not existing_food:
            formatted_results.append(result)
    
    conn.close()
    return formatted_results[:10]

def format_food(food):
    if isinstance(food, sqlite3.Row):
        food = dict(food)
    return {
        'id': food.get('id'),
        'name': food.get('name'),
        'serving': food.get('serving_size'),
        'calories': food.get('calories'),
        'protein': food.get('protein'),
        'carbs': food.get('carbs'),
        'fat': food.get('fat')
    }

@app.route('/api/meals', methods=['GET'])
def get_meals():
    date_str = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute("""
        SELECT m.*, f.*
        FROM meal_entries m
        JOIN foods f ON m.food_id = f.id
        WHERE m.date = ?
    """, (date_str,))
    
    meals = c.fetchall()
    conn.close()
    
    result = {
        'Breakfast': [],
        'Lunch': [],
        'Dinner': [],
        'Snacks': []
    }
    
    for meal in meals:
        meal_dict = dict(meal)
        result[meal_dict['meal_type']].append({
            'id': meal_dict['food_id'],
            'name': meal_dict['name'],
            'serving': meal_dict['serving_size'],
            'quantity': meal_dict['quantity'],
            'calories': meal_dict['calories'],
            'protein': meal_dict['protein'],
            'carbs': meal_dict['carbs'],
            'fat': meal_dict['fat']
        })
    
    return jsonify(result)

@app.route('/api/meals', methods=['POST'])
def add_meal():
    data = request.json
    conn = get_db()
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO meal_entries (food_id, meal_type, quantity, date)
        VALUES (?, ?, ?, ?)
    """, (
        data['food_id'],
        data['meal_type'],
        data['quantity'],
        data.get('date', datetime.now().strftime('%Y-%m-%d'))
    ))
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Meal added successfully'})

@app.route('/api/meals/<int:meal_id>', methods=['DELETE'])
def delete_meal(meal_id):
    conn = get_db()
    c = conn.cursor()
    
    c.execute("DELETE FROM meal_entries WHERE id = ?", (meal_id,))
    
    if c.rowcount == 0:
        conn.close()
        return jsonify({'error': 'Meal not found'}), 404
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Meal deleted successfully'})

if __name__ == '__main__':
    app.run(debug=True)