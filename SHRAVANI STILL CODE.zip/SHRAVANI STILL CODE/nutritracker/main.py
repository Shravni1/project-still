from flask import Flask, render_template, request, jsonify, g
import sqlite3
import requests
from datetime import datetime
import os

app = Flask(__name__)

# Edamam API credentials - replace with your own
EDAMAM_APP_ID = "44b87180"
EDAMAM_APP_KEY = "d5720713e7c975d5313bddf77eda13be"
EDAMAM_API_URL = "https://api.edamam.com/api/recipes/v2"

# Database configuration
DATABASE = 'nutrition_tracker.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/search_recipe', methods=['GET'])
def search_recipe():
    query = request.args.get('query', '')
    params = {
        'type': 'public',
        'q': query,
        'app_id': EDAMAM_APP_ID,
        'app_key': EDAMAM_APP_KEY
    }
    
    try:
        response = requests.get(EDAMAM_API_URL, params=params)
        data = response.json()
        
        recipes = []
        for hit in data.get('hits', []):
            recipe = hit['recipe']
            recipes.append({
                'id': recipe['uri'].split('_')[1],
                'name': recipe['label'],
                'calories': round(recipe['calories']),
                'protein': round(recipe['totalNutrients'].get('PROCNT', {}).get('quantity', 0)),
                'carbs': round(recipe['totalNutrients'].get('CHOCDF', {}).get('quantity', 0)),
                'fat': round(recipe['totalNutrients'].get('FAT', {}).get('quantity', 0)),
                'image': recipe.get('image', '')
            })
        return jsonify(recipes)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    

@app.route('/api/add_meal', methods=['POST'])
def add_meal():
    meal_data = request.json
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO meals (name, category, portion_size, calories, protein, carbs, fat, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            meal_data['name'],
            meal_data['category'],
            meal_data['portionSize'],
            meal_data['calories'] * meal_data['portionSize'],
            meal_data['protein'] * meal_data['portionSize'],
            meal_data['carbs'] * meal_data['portionSize'],
            meal_data['fat'] * meal_data['portionSize'],
            datetime.now().isoformat()
        ))
        db.commit()
        return jsonify({"message": "Meal added successfully"})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/get_meals', methods=['GET'])
def get_meals():
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute('SELECT * FROM meals ORDER BY timestamp DESC')
        meals = cursor.fetchall()
        return jsonify([{
            'id': meal['id'],
            'name': meal['name'],
            'category': meal['category'],
            'portion_size': meal['portion_size'],
            'calories': meal['calories'],
            'protein': meal['protein'],
            'carbs': meal['carbs'],
            'fat': meal['fat'],
            'timestamp': meal['timestamp']
        } for meal in meals])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/remove_meal', methods=['DELETE'])
def remove_meal():
    meal_id = request.args.get('id')
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute('DELETE FROM meals WHERE id = ?', (meal_id,))
        db.commit()
        return jsonify({"message": "Meal removed successfully"})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=True)
    
    let currentRecipes = [];
        let todaysMeals = [];
        let macronutrientChart;
        let caloriesTrendChart;

        // Edamam API credentials
        const APP_ID = '44b87180'; // Replace with your Edamam App ID
        const APP_KEY = 'd5720713e7c975d5313bddf77eda13be'; // Replace with your Edamam App Key

        // Initialize charts
        function initCharts() {
            const macronutrientCtx = document.getElementById('macronutrientChart').getContext('2d');
            macronutrientChart = new Chart(macronutrientCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Protein', 'Carbs', 'Fat'],
                    datasets: [{
                        label: 'Macronutrients',
                        data: [0, 0, 0],
                        backgroundColor: ['#FF9F43', '#00CFE8', '#28C76F'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `${context.label}: ${context.raw}g`;
                                }
                            }
                        }
                    }
                }
            });

            const caloriesTrendCtx = document.getElementById('caloriesTrendChart').getContext('2d');
            caloriesTrendChart = new Chart(caloriesTrendCtx, {
                type: 'line',
                data: {
                    labels: [], // Dates will be added dynamically
                    datasets: [{
                        label: 'Daily Calorie Intake',
                        data: [], // Calorie data will be added dynamically
                        borderColor: '#447B66',
                        fill: false,
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Calories'
                            }
                        }
                    }
                }
            });
        }

        // Fetch recipes from Edamam API
        async function searchRecipes(query) {
            if (query.length < 2) {
                currentRecipes = [];
                renderSearchResults();
                return;
            }

            const apiUrl = `https://api.edamam.com/api/recipes/v2?type=public&q=${encodeURIComponent(query)}&app_id=${APP_ID}&app_key=${APP_KEY}`;

            try {
                const response = await fetch(apiUrl);
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json();

                // Map the Edamam API response to your recipe structure
                currentRecipes = data.hits.map(hit => ({
                    id: hit.recipe.uri, // Use the recipe URI as a unique ID
                    name: hit.recipe.label,
                    image: hit.recipe.image,
                    calories: hit.recipe.calories,
                    protein: hit.recipe.totalNutrients.PROCNT?.quantity || 0, // Protein in grams
                    carbs: hit.recipe.totalNutrients.CHOCDF?.quantity || 0, // Carbs in grams
                    fat: hit.recipe.totalNutrients.FAT?.quantity || 0 // Fat in grams
                }));

                renderSearchResults();
            } catch (error) {
                console.error('Error fetching recipes from Edamam API:', error);
                document.getElementById('searchResults').innerHTML = `
                    <div class="meal-card">
                        <div class="meal-content">
                            <h3>Error fetching recipes</h3>
                            <p>Please try again later</p>
                        </div>
                    </div>
                `;
            }
        }

        // Render search results
        function renderSearchResults() {
            document.getElementById('searchResults').innerHTML = currentRecipes.map(recipe => `
                <div class="meal-card" data-recipe-id="${recipe.id}">
                    <img src="${recipe.image}" alt="${recipe.name}" class="meal-image">
                    <div class="meal-content">
                        <h3>${recipe.name}</h3>
                        <div class="meal-info">
                            <span data-original-calories="${recipe.calories}">Calories: ${Math.round(recipe.calories)}</span>
                            <span data-original-protein="${recipe.protein}">Protein: ${Math.round(recipe.protein)}g</span>
                            <span data-original-carbs="${recipe.carbs}">Carbs: ${Math.round(recipe.carbs)}g</span>
                            <span data-original-fat="${recipe.fat}">Fat: ${Math.round(recipe.fat)}g</span>
                        </div>
                    </div>
                    <div class="controls">
                        <select class="meal-category">
                            <option value="breakfast">Breakfast</option>
                            <option value="lunch">Lunch</option>
                            <option value="dinner">Dinner</option>
                            <option value="snack">Snack</option>
                        </select>
                        <input type="number" class="portion-size" value="1" min="0.25" max="5" step="0.25" onchange="updateNutritionPreview('${recipe.id}')">
                        <button onclick="addMeal('${recipe.id}')">Add</button>
                    </div>
                </div>
            `).join('');
        }

        // Add meal
        function addMeal(recipeId) {
            const recipe = currentRecipes.find(r => r.id === recipeId);
            const mealCard = event.target.closest('.meal-card');
            const category = mealCard.querySelector('.meal-category').value;
            const portionSize = parseFloat(mealCard.querySelector('.portion-size').value);

            const newMeal = {
                ...recipe,
                id: Date.now(),
                category,
                portionSize
            };

            todaysMeals.push(newMeal);
            updateNutritionSummary();
            updateCharts();
            renderMeals();
        }

        // Remove meal
        function removeMeal(mealId) {
            todaysMeals = todaysMeals.filter(meal => meal.id !== mealId);
            updateNutritionSummary();
            updateCharts();
            renderMeals();
        }

        // Update portion
        function updatePortion(mealId, newPortion) {
            todaysMeals = todaysMeals.map(meal =>
                meal.id === mealId ? { ...meal, portionSize: newPortion } : meal
            );
            updateNutritionSummary();
            updateCharts();
            renderMeals();
        }

        // Render meals
        function renderMeals() {
            const categoryFilter = document.getElementById('categoryFilter').value;
            const filteredMeals = categoryFilter === 'all' 
                ? todaysMeals 
                : todaysMeals.filter(meal => meal.category === categoryFilter);

            document.getElementById('mealsList').innerHTML = filteredMeals.map(meal => `
                <div class="meal-card">
                    <img src="${meal.image}" alt="${meal.name}" class="meal-image">
                    <div class="meal-content">
                        <h3>${meal.name}</h3>
                        <span class="category-badge">${meal.category}</span>
                        <div class="meal-info">
                            <span>Calories: ${Math.round(meal.calories * meal.portionSize)}</span>
                            <span>Protein: ${Math.round(meal.protein * meal.portionSize)}g</span>
                            <span>Carbs: ${Math.round(meal.carbs * meal.portionSize)}g</span>
                            <span>Fat: ${Math.round(meal.fat * meal.portionSize)}g</span>
                        </div>
                    </div>
                    <div class="controls">
                        <input type="number" 
                               value="${meal.portionSize}" 
                               min="0.25" 
                               max="5" 
                               step="0.25"
                               onchange="updatePortion(${meal.id}, this.value)">
                        <button class="delete-btn" onclick="removeMeal(${meal.id})">Remove</button>
                    </div>
                </div>
            `).join('');
        }

        // Calculate nutrition totals
        function calculateTotals() {
            return todaysMeals.reduce((acc, meal) => ({
                calories: acc.calories + meal.calories * meal.portionSize,
                protein: acc.protein + meal.protein * meal.portionSize,
                carbs: acc.carbs + meal.carbs * meal.portionSize,
                fat: acc.fat + meal.fat * meal.portionSize
            }), { calories: 0, protein: 0, carbs: 0, fat: 0 });
        }

        // Update nutrition summary
        function updateNutritionSummary() {
            const totals = calculateTotals();
            document.getElementById('totalCalories').textContent = Math.round(totals.calories);
            document.getElementById('totalProtein').textContent = Math.round(totals.protein) + 'g';
            document.getElementById('totalCarbs').textContent = Math.round(totals.carbs) + 'g';
            document.getElementById('totalFat').textContent = Math.round(totals.fat) + 'g';

            // Update macronutrient chart
            macronutrientChart.data.datasets[0].data = [totals.protein, totals.carbs, totals.fat];
            macronutrientChart.update();
        }

        // Update charts
        function updateCharts() {
            updateNutritionSummary();
            updateCaloriesTrendChart();
        }

        // Update calories trend chart
        function updateCaloriesTrendChart() {
            const dates = ['2023-10-01', '2023-10-02', '2023-10-03']; // Example dates
            const calorieData = [2000, 2200, 2100]; // Example calorie data

            caloriesTrendChart.data.labels = dates;
            caloriesTrendChart.data.datasets[0].data = calorieData;
            caloriesTrendChart.update();
        }

        // Initialize
        document.getElementById('searchInput').addEventListener('input', (e) => {
            searchRecipes(e.target.value);
        });

        document.getElementById('categoryFilter').addEventListener('change', renderMeals);

        // Initialize charts on load
        initCharts();