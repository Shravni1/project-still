from flask import Flask, request, jsonify, render_template
import requests
import os

app = Flask(__name__)

# Edamam API credentials
EDAMAM_APP_ID = "44b87180"
EDAMAM_APP_KEY = "d5720713e7c975d5313bddf77eda13be"
EDAMAM_BASE_URL = "https://api.edamam.com/api/recipes/v2"

# Serve the main page
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/search-recipes', methods=['GET'])
def search_recipes():
    query = request.args.get('query', '')
    
    if not query:
        return jsonify([])
    
    # Parameters for Edamam API
    params = {
        'type': 'public',
        'q': query,
        'app_id': EDAMAM_APP_ID,
        'app_key': EDAMAM_APP_KEY,
        'field': ['label', 'image', 'calories', 'totalNutrients']
    }
    
    try:
        response = requests.get(EDAMAM_BASE_URL, params=params)
        response.raise_for_status()
        data = response.json()
        
        # Transform Edamam response to match our frontend format
        recipes = []
        for hit in data.get('hits', []):
            recipe = hit['recipe']
            nutrients = recipe.get('totalNutrients', {})
            
            # Extract nutrients (converting from kCal/g to g)
            protein = nutrients.get('PROCNT', {}).get('quantity', 0)
            carbs = nutrients.get('CHOCDF', {}).get('quantity', 0)
            fat = nutrients.get('FAT', {}).get('quantity', 0)
            
            recipes.append({
                'id': hit['_links']['self']['href'].split('/')[-1],  # Extract ID from self link
                'name': recipe['label'],
                'image': recipe['image'],
                'calories': round(recipe['calories'] / recipe.get('yield', 1)),  # Per serving
                'protein': round(protein / recipe.get('yield', 1)),
                'carbs': round(carbs / recipe.get('yield', 1)),
                'fat': round(fat / recipe.get('yield', 1))
            })
        
        return jsonify(recipes)
    
    except requests.exceptions.RequestException as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)