from flask import Flask, render_template, request, jsonify, g
import sqlite3
import requests
from datetime import datetime
import os

app = Flask(__name__)

# Edamam API credentials - replace with your own
EDAMAM_APP_ID = "44b87180"
EDAMAM_APP_KEY = "d5720713e7c975d5313bddf77eda13be"
EDAMAM_API_URL = "https://api.edamam.com/api/recipes/v2"

# Database configuration
DATABASE = 'nutrition.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/search_recipe', methods=['GET'])
def search_recipe():
    query = request.args.get('query', '')
    params = {
        'type': 'public',
        'q': query,
        'app_id': EDAMAM_APP_ID,
        'app_key': EDAMAM_APP_KEY
    }
    
    try:
        response = requests.get(EDAMAM_API_URL, params=params)
        data = response.json()
        
        recipes = []
        for hit in data.get('hits', []):
            recipe = hit['recipe']
            recipes.append({
                'id': recipe['uri'].split('_')[1],
                'name': recipe['label'],
                'calories': round(recipe['calories']),
                'protein': round(recipe['totalNutrients'].get('PROCNT', {}).get('quantity', 0)),
                'carbs': round(recipe['totalNutrients'].get('CHOCDF', {}).get('quantity', 0)),
                'fat': round(recipe['totalNutrients'].get('FAT', {}).get('quantity', 0)),
                'image': recipe.get('image', '')
            })
        return jsonify(recipes)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/add_meal', methods=['POST'])
def add_meal():
    meal_data = request.json
    db = get_db()
    cursor = db.cursor()
    
    try:
        # Calculate nutrition based on portion size
        portion_size = float(meal_data['portionSize'])
        calories = round(meal_data['calories'] * portion_size)
        protein = round(meal_data['protein'] * portion_size)
        carbs = round(meal_data['carbs'] * portion_size)
        fat = round(meal_data['fat'] * portion_size)
        
        cursor.execute('''
            INSERT INTO meals (
                name, 
                category, 
                portion_size, 
                calories, 
                protein, 
                carbs, 
                fat, 
                timestamp,
                image,
                base_calories,
                base_protein,
                base_carbs,
                base_fat
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            meal_data['name'],
            meal_data['category'],
            portion_size,
            calories,
            protein,
            carbs,
            fat,
            datetime.now().isoformat(),
            meal_data['image'],  # Store the image URL
            meal_data['calories'],  # Store base values for later portion adjustments
            meal_data['protein'],
            meal_data['carbs'],
            meal_data['fat']
        ))
        db.commit()
        
        # Return updated meal list and nutrition totals
        return get_nutrition_data()
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/update_portion', methods=['PUT'])
def update_portion():
    meal_id = request.json.get('id')
    new_portion = float(request.json.get('portionSize'))
    
    db = get_db()
    cursor = db.cursor()
    
    try:
        # Get the base nutrition values
        cursor.execute('''
            SELECT base_calories, base_protein, base_carbs, base_fat
            FROM meals WHERE id = ?
        ''', (meal_id,))
        base_values = cursor.fetchone()
        
        # Calculate new nutrition values
        new_calories = round(base_values['base_calories'] * new_portion)
        new_protein = round(base_values['base_protein'] * new_portion)
        new_carbs = round(base_values['base_carbs'] * new_portion)
        new_fat = round(base_values['base_fat'] * new_portion)
        
        # Update the meal
        cursor.execute('''
            UPDATE meals 
            SET portion_size = ?,
                calories = ?,
                protein = ?,
                carbs = ?,
                fat = ?
            WHERE id = ?
        ''', (new_portion, new_calories, new_protein, new_carbs, new_fat, meal_id))
        db.commit()
        
        # Return updated meal list and nutrition totals
        return get_nutrition_data()
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/get_meals', methods=['GET'])
def get_meals():
    return get_nutrition_data()

def get_nutrition_data():
    db = get_db()
    cursor = db.cursor()
    
    try:
        # Get all meals
        cursor.execute('''
            SELECT * FROM meals 
            WHERE date(timestamp) = date('now')
            ORDER BY timestamp DESC
        ''')
        meals = cursor.fetchall()
        
        # Calculate totals by category
        category_totals = {}
        for meal in meals:
            category = meal['category']
            if category not in category_totals:
                category_totals[category] = {
                    'calories': 0,
                    'protein': 0,
                    'carbs': 0,
                    'fat': 0
                }
            category_totals[category]['calories'] += meal['calories']
            category_totals[category]['protein'] += meal['protein']
            category_totals[category]['carbs'] += meal['carbs']
            category_totals[category]['fat'] += meal['fat']
        
        # Calculate daily totals
        daily_totals = {
            'calories': sum(cat['calories'] for cat in category_totals.values()),
            'protein': sum(cat['protein'] for cat in category_totals.values()),
            'carbs': sum(cat['carbs'] for cat in category_totals.values()),
            'fat': sum(cat['fat'] for cat in category_totals.values())
        }
        
        return jsonify({
            'meals': [{
                'id': meal['id'],
                'name': meal['name'],
                'category': meal['category'],
                'portion_size': meal['portion_size'],
                'calories': meal['calories'],
                'protein': meal['protein'],
                'carbs': meal['carbs'],
                'fat': meal['fat'],
                'image': meal['image'],  # Include image in the response
                'timestamp': meal['timestamp']
            } for meal in meals],
            'category_totals': category_totals,
            'daily_totals': daily_totals
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/remove_meal', methods=['DELETE'])
def remove_meal():
    meal_id = request.args.get('id')
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute('DELETE FROM meals WHERE id = ?', (meal_id,))
        db.commit()
        
        # Return updated meal list and nutrition totals
        return get_nutrition_data()
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=True)