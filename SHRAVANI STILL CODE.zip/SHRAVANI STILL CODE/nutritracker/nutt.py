from flask import Flask, render_template, request, jsonify, g
import sqlite3
import requests
from datetime import datetime
import os

app = Flask(__name__)

# Edamam API credentials - replace with your own
EDAMAM_APP_ID = "44b87180"
EDAMAM_APP_KEY = "d5720713e7c975d5313bddf77eda13be"
EDAMAM_API_URL = "https://api.edamam.com/api/recipes/v2"

# Database configuration
DATABASE = 'nutrition_tracker.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/search_recipe', methods=['GET'])
def search_recipe():
    query = request.args.get('query', '').strip()
    
    if not query:
        return jsonify({'error': 'Please enter a search term'}), 400
        
    try:
        params = {
            'type': 'public',
            'q': query,
            'app_id': EDAMAM_APP_ID,
            'app_key': EDAMAM_APP_KEY,
            'field': ['uri', 'label', 'image', 'calories', 'totalNutrients']
        }
        
        response = requests.get(EDAMAM_API_URL, params=params)
        response.raise_for_status()  # Raise exception for bad status codes
        data = response.json()
        
        recipes = []
        for hit in data.get('hits', []):
            recipe = hit['recipe']
            nutrients = recipe.get('totalNutrients', {})
            
            processed_recipe = {
                'id': recipe['uri'].split('_')[1],
                'name': recipe['label'],
                'image': recipe.get('image', ''),
                'calories': round(recipe['calories'] / recipe.get('yield', 1)),
                'protein': round(nutrients.get('PROCNT', {}).get('quantity', 0) / recipe.get('yield', 1)),
                'carbs': round(nutrients.get('CHOCDF', {}).get('quantity', 0) / recipe.get('yield', 1)),
                'fat': round(nutrients.get('FAT', {}).get('quantity', 0) / recipe.get('yield', 1)),
                'servingSize': 1,
                'yield': recipe.get('yield', 1)
            }
            recipes.append(processed_recipe)
            
        return jsonify({
            'success': True,
            'recipes': recipes,
            'total': len(recipes)
        })
        
    except requests.RequestException as e:
        return jsonify({
            'error': 'Failed to fetch recipes',
            'message': str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'error': 'An unexpected error occurred',
            'message': str(e)
        }), 500

@app.route('/api/add_meal', methods=['POST'])
def add_meal():
    meal_data = request.json
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO meals (name, category, portion_size, calories, protein, carbs, fat, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            meal_data['name'],
            meal_data['category'],
            meal_data['portionSize'],
            meal_data['calories'] * meal_data['portionSize'],
            meal_data['protein'] * meal_data['portionSize'],
            meal_data['carbs'] * meal_data['portionSize'],
            meal_data['fat'] * meal_data['portionSize'],
            datetime.now().isoformat()
        ))
        db.commit()
        return jsonify({"message": "Meal added successfully"})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/get_meals', methods=['GET'])
def get_meals():
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute('SELECT * FROM meals ORDER BY timestamp DESC')
        meals = cursor.fetchall()
        return jsonify([{
            'id': meal['id'],
            'name': meal['name'],
            'category': meal['category'],
            'portion_size': meal['portion_size'],
            'calories': meal['calories'],
            'protein': meal['protein'],
            'carbs': meal['carbs'],
            'fat': meal['fat'],
            'timestamp': meal['timestamp']
        } for meal in meals])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/remove_meal', methods=['DELETE'])
def remove_meal():
    meal_id = request.args.get('id')
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute('DELETE FROM meals WHERE id = ?', (meal_id,))
        db.commit()
        return jsonify({"message": "Meal removed successfully"})
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=True)