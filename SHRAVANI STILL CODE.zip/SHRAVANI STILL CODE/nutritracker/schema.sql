CREATE TABLE IF NOT EXISTS meals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    portion_size REAL NOT NULL,
    calories INTEGER NOT NULL,
    protein INTEGER NOT NULL,
    carbs INTEGER NOT NULL,
    fat INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    image TEXT,
    base_calories INTEGER NOT NULL,
    base_protein INTEGER NOT NULL,
    base_carbs INTEGER NOT NULL,
    base_fat INTEGER NOT NULL
);