from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import sqlite3
import os
import re
import google.generativeai as generativeai
import google.generativeai as genai
import requests

from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()




app = Flask(__name__)
app.secret_key = "AIzaSyCVFC9kVCBjpYfzGRCJ68Ei2qEPYdswOjk"

# Configuring the API key
GOOGLE_GEMINI_KEY = os.getenv("GOOGLE_GEMINI_KEY")
generativeai.configure(api_key=GOOGLE_GEMINI_KEY)

# Database setup
def init_db():
    conn = sqlite3.connect('recipes.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    password TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS recipes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    recipe_name TEXT,
                    ingredients TEXT,
                    instructions TEXT,
                    tips TEXT,
                    nutrition TEXT,
                    FOREIGN KEY(user_id) REFERENCES users(id))''')
    conn.commit()
    conn.close()



# Routes
@app.route('/')
def home():
    return render_template('home.html')

# Function to get LLM response using Gemini 1.5 Pro
def get_gemini_response(prompt, question):
    # Use the Gemini 1.5 Pro model
    model = genai.GenerativeModel(model_name="gemini-1.5-pro")  # Updated to Gemini 1.5 Pro
    response = model.generate_content(f"{prompt}\n\n{question}")
    return response.text

# Fetch recipe image
def fetch_recipe_image(recipe_name):
    GOOGLE_API_KEY = "AIzaSyDkAnRfRTHK4TChepiC94My3DF_HkZADEs"  # Replace with your API key
    SEARCH_ENGINE_ID = "9360885785bec478e"  # Replace with your Search Engine ID
    try:
        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            "q": recipe_name,
            "cx": SEARCH_ENGINE_ID,
            "key": GOOGLE_API_KEY,
            "searchType": "image",
            "num": 1,
        }
        response = requests.get(url, params=params)
        response.raise_for_status()
        results = response.json().get("items", [])
        if results:
            return results[0]["link"]
    except requests.exceptions.RequestException as e:
        print(f"Image API error: {e}")
    return "https://via.placeholder.com/300"  # Fallback image


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('recipes.db')
        c = conn.cursor()
        c.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        conn.commit()
        conn.close()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('recipes.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            return redirect(url_for('generate_recipe'))
        else:
            return "Invalid credentials!"
    return render_template('login.html')


@app.template_filter('regex_replace')
def regex_replace(value, pattern, replacement):
    return re.sub(pattern, replacement, value)  

@app.route('/generate_recipe', methods=['GET', 'POST'])
def generate_recipe():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        cuisine = request.form['cuisine']
        meal_type = request.form['meal_type']
        diet = request.form['diet']
        prep_time = request.form['prep_time']
        servings = request.form['servings']
        ingredients = request.form['ingredients']
        unwanted_ingredients = request.form['unwanted_ingredients']

        question = f"""
        Create a recipe for a {meal_type} in {cuisine} cuisine that adheres to a {diet} diet. 
        It should take less than {prep_time} minutes to prepare, serve {servings} people, and include the following ingredients: {ingredients}. 
        Avoid using these ingredients: {unwanted_ingredients}.
        """

        prompt = """
        You are an expert in generating recipes. Generate a detailed recipe including:
        - Recipe Name
        - Ingredients (in structured format as: Ingredient Name, Quantity, Calories)
        - Instructions (step-by-step)
        - Tips
        - Nutrition Information
        """

        recipe_response = get_gemini_response(prompt, question)
        recipe_data = recipe_response.split('\n\n')  # Parse the response
        recipe_name = recipe_data[0].strip()
        ingredients = recipe_data[2].strip()
        instructions = recipe_data[4].strip()
        tips = recipe_data[6].strip()
        nutrition = recipe_data[8].strip()

        # Save the recipe in the database
        conn = sqlite3.connect('recipes.db')
        c = conn.cursor()
        c.execute('INSERT INTO recipes (user_id, recipe_name, ingredients, instructions, tips, nutrition) VALUES (?, ?, ?, ?, ?, ?)', 
                  (session['user_id'], recipe_name, ingredients, instructions, tips, nutrition))
        conn.commit()
        conn.close()

        return redirect(url_for('view_recipes'))
    return render_template('generate_recipe.html')

@app.route('/view_recipes')
def view_recipes():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('recipes.db')
    c = conn.cursor()
    # Fetch only the most recent recipe for the logged-in user
    c.execute(''' 
        SELECT recipe_name, ingredients, instructions, tips, nutrition 
        FROM recipes 
        WHERE user_id = ? 
        ORDER BY id DESC 
        LIMIT 1
    ''', (session['user_id'],))
    recipe = c.fetchone()
    conn.close()

    # Fetch recipe image using the recipe name
    recipe_image = fetch_recipe_image(recipe[0]) if recipe else None

    # Pass the single recipe (or None) and the image URL to the template
    return render_template('view_recipes.html', recipe=recipe, recipe_image=recipe_image)


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
