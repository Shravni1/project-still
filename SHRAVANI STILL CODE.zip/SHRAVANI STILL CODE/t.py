from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import sqlite3
import os
import re
import google.generativeai as genai
import requests
from dotenv import load_dotenv
from urllib.parse import quote, unquote

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "default_secret_key")

# Configure the API key
GOOGLE_GEMINI_KEY = os.getenv("GOOGLE_GEMINI_KEY")
genai.configure(api_key=GOOGLE_GEMINI_KEY)

# Database setup
def init_db():
    conn = sqlite3.connect('recipedata.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    password TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS recipes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    recipe_name TEXT,
                    ingredients TEXT,
                    instructions TEXT,
                    tips TEXT,
                    nutrition TEXT,
                    prep_time INTEGER,
                    servings INTEGER,
                    total_calories INTEGER,
                    FOREIGN KEY(user_id) REFERENCES users(id))''')
    conn.commit()
    conn.close()

# Function to get LLM response
def get_gemini_response(prompt, question):
    model = genai.GenerativeModel(model_name="gemini-1.5-flash")  # Updated to gemini-1.5-flash
    response = model.generate_content(f"{prompt}\n\n{question}")
    print("Raw Gemini API Response:\n", response.text)  # Debugging: Print the raw response
    return response.text

# Fetch recipe image
def fetch_recipe_image(recipe_name):
    GOOGLE_API_KEY = "AIzaSyDkAnRfRTHK4TChepiC94My3DF_HkZADEs"  # Replace with your API key
    SEARCH_ENGINE_ID = "9360885785bec478e"  # Replace with your Search Engine ID
    try:
        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            "q": recipe_name,
            "cx": SEARCH_ENGINE_ID,
            "key": GOOGLE_API_KEY,
            "searchType": "image",
            "num": 1,
        }
        response = requests.get(url, params=params)
        response.raise_for_status()
        results = response.json().get("items", [])
        if results:
            return results[0]["link"]
    except requests.exceptions.RequestException as e:
        print(f"Image API error: {e}")
    return "https://via.placeholder.com/300"  # Fallback image

# Parse the Gemini API response
def parse_recipe_response(response):
    recipe = {
        "recipe_name": "",
        "ingredients": "",
        "instructions": "",
        "tips": "",
        "nutrition": "",
    }

    # Split the response into lines
    lines = response.split("\n")

    # Iterate through lines and assign values based on keywords
    current_section = None
    for line in lines:
        line = line.strip()
        if line.startswith("Recipe Name:"):
            recipe["recipe_name"] = line.replace("Recipe Name:", "").strip()
        elif line.startswith("Ingredients:"):
            current_section = "ingredients"
            recipe["ingredients"] = line.replace("Ingredients:", "").strip()
        elif line.startswith("Instructions:"):
            current_section = "instructions"
            recipe["instructions"] = line.replace("Instructions:", "").strip()
        elif line.startswith("Tips:"):
            current_section = "tips"
            recipe["tips"] = line.replace("Tips:", "").strip()
        elif line.startswith("Nutrition Information:"):
            current_section = "nutrition"
            recipe["nutrition"] = line.replace("Nutrition Information:", "").strip()
        elif current_section:
            # Append additional lines to the current section
            recipe[current_section] += "\n" + line

    return recipe

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('recipedata.db')
        c = conn.cursor()
        c.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        conn.commit()
        conn.close()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('recipedata.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            return redirect(url_for('generate_recipe'))
        else:
            return "Invalid credentials!"
    return render_template('login.html')

@app.route('/generate_recipe', methods=['GET', 'POST'])
def generate_recipe():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        session['cuisine'] = request.form['cuisine']
        session['meal_type'] = request.form['meal_type']
        session['diet'] = request.form['diet']
        session['prep_time'] = request.form['prep_time']
        session['servings'] = request.form['servings']
        session['ingredients'] = request.form['ingredients']
        session['unwanted_ingredients'] = request.form['unwanted_ingredients']
        
        cuisine = session.get('cuisine', '')
        meal_type = session.get('meal_type', '')
        diet = session.get('diet', '')
        prep_time = session.get('prep_time', '')
        servings = session.get('servings', '')
        ingredients = session.get('ingredients', '')
        unwanted_ingredients = session.get('unwanted_ingredients', '')

        question = f"""
        Create a recipe for a {meal_type} in {cuisine} cuisine that adheres to a {diet} diet. 
        It should take less than {prep_time} minutes to prepare, serve {servings} people, and include the following ingredients: {ingredients}. 
        Avoid using these ingredients: {unwanted_ingredients}.
        """

        prompt = """
        You are an expert in generating recipes. Generate a detailed recipe including:
        - Recipe Name: <name>
        - Ingredients: <list of ingredients with quantities and calories>
        - Instructions: <step-by-step instructions>
        - Tips: <cooking tips>
        - Nutrition Information: <nutritional details>

        Each section must start with the section name followed by a colon (:). For example:
        - Recipe Name: Pasta Carbonara
        - Ingredients: 
          - Spaghetti, 200g, 200 calories
          - Eggs, 2, 140 calories
        - Instructions:
          1. Boil the spaghetti.
          2. Mix eggs with cheese.
        - Tips:
          - Use fresh eggs for better flavor.
        - Nutrition Information:
          - Calories: 340 per serving
        """

        recipe_response = get_gemini_response(prompt, question)
        recipe = parse_recipe_response(recipe_response)

        # Calculate total calories
        total_calories = 0
        for line in recipe["ingredients"].split('\n'):
            if line.strip():
                try:
                    # Extracts the first numeric value from the calorie string
                    calories_match = re.search(r'(\d+)\s*(?:calories|calorie)', line)
                    if calories_match:
                         total_calories += int(calories_match.group(1))
                except ValueError:
                    continue  # Skip lines where conversion fails

        conn = sqlite3.connect('recipedata.db')
        c = conn.cursor()
        c.execute('INSERT INTO recipes (user_id, recipe_name, ingredients, instructions, tips, nutrition, prep_time, servings, total_calories) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                  (session['user_id'], recipe["recipe_name"], recipe["ingredients"], recipe["instructions"], recipe["tips"], recipe["nutrition"], prep_time, servings, total_calories))
        recipe_id = c.lastrowid 
        conn.commit()
        conn.close()

        return redirect(url_for('view_recipe', recipe_id=recipe_id))
    return render_template('generate_recipe.html')

@app.route('/view_recipe/<int:recipe_id>')
def view_recipe(recipe_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('recipedata.db')
    c = conn.cursor()
    
    # FIX: Use TWO placeholders since there are TWO values
    c.execute('''SELECT recipe_name, ingredients, instructions, tips, nutrition, prep_time, servings, total_calories 
                 FROM recipes WHERE id = ? AND user_id = ?''', (recipe_id, session['user_id']))
    
    recipe = c.fetchone()
    conn.close()

    if not recipe:
        return "Recipe not found!", 404

    recipe_image = fetch_recipe_image(recipe[0])

    return render_template('view_recipes.html', recipe=recipe, recipe_image=recipe_image)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)