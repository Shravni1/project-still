document.addEventListener("DOMContentLoaded", function () {
    let currentStep = 0;  // To keep track of the current step
    const form = document.getElementById("multi-step-form");
    const steps = form.getElementsByClassName("step");
    const nextButtons = form.getElementsByClassName("next-btn");
    const backButtons = form.getElementsByClassName("back-btn");
    const inputs = {}; // Object to store user input

    // Function to show or hide steps based on the current step
    function showStep(stepIndex) {
        for (let i = 0; i < steps.length; i++) {
            steps[i].classList.remove("active");
        }
        steps[stepIndex].classList.add("active");
    }

    // Event listener for Next buttons
    for (let i = 0; i < nextButtons.length; i++) {
        nextButtons[i].addEventListener("click", function () {
            // Collect data from the current step
            const currentStepElement = steps[currentStep];
            collectInputData(currentStepElement);

            // Move to the next step
            if (currentStep < steps.length - 1) {
                currentStep++;
                showStep(currentStep);
            }
        });
    }

    // Event listener for Back buttons
    for (let i = 0; i < backButtons.length; i++) {
        backButtons[i].addEventListener("click", function () {
            // Move to the previous step
            if (currentStep > 0) {
                currentStep--;
                showStep(currentStep);
            }
        });
    }

    // Function to collect data from each step
    function collectInputData(stepElement) {
        const inputsInStep = stepElement.querySelectorAll("input, button");
        
        inputsInStep.forEach(input => {
            if (input.type === "text" || input.type === "number" || input.type === "radio" || input.type === "checkbox") {
                if (input.type === "radio" && input.checked) {
                    inputs[input.name] = input.value;
                } else if (input.type === "checkbox" && input.checked) {
                    if (!inputs[input.name]) {
                        inputs[input.name] = [];
                    }
                    inputs[input.name].push(input.value);
                } else if (input.type === "text" || input.type === "number") {
                    inputs[input.id] = input.value;
                }
            }
        });
    }

    // Handle form submission
    form.addEventListener("submit", function (e) {
        e.preventDefault(); // Prevent form from actually submitting
        collectInputData(steps[currentStep]);  // Collect last step data

        console.log("Form Data Collected: ", inputs);

        // Here, you can process the collected data as needed (e.g., send to a server)
        alert("Form Submitted Successfully!");
    });

    // Initialize the first step
    showStep(currentStep);
});
