from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
import openai
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATABASE = 'users.db'

def init_db():
    if not os.path.exists(DATABASE):
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            username TEXT UNIQUE NOT NULL,
                            password TEXT NOT NULL)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS user_profiles (
                            user_id INTEGER,
                            age INTEGER,
                            gender TEXT,
                            height TEXT,
                            weight INTEGER,
                            activity TEXT,
                            goals TEXT,
                            health TEXT,
                            taste TEXT,
                            allergies TEXT,
                            FOREIGN KEY(user_id) REFERENCES users(id))''')
        conn.commit()
        conn.close()

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not username or not password:
            return 'Please provide a username and password!'
        
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
        except sqlite3.IntegrityError:
            return 'Username already exists!'
        conn.close()
        return redirect(url_for('home'))
    return render_template('register.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    if not username or not password:
        return 'Invalid credentials, try again!'
    
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, password FROM users WHERE username=?", (username,))
    user = cursor.fetchone()
    conn.close()
    
    if user and user[1] == password:
        session['user_id'] = user[0]
        return redirect(url_for('onboarding'))
    return 'Invalid credentials, try again!'

@app.route('/onboarding', methods=['GET', 'POST'])
def onboarding():
    if request.method == 'POST':
        user_id = session.get('user_id')
        if not user_id:
            return redirect(url_for('home'))
        data = request.form.to_dict()
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO user_profiles (user_id, age, gender, height, weight, activity, goals, health, taste, allergies)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                       (user_id, data['age'], data['gender'], data['height'], data['weight'], data['activity'],
                        ','.join(request.form.getlist('goals')), ','.join(request.form.getlist('health')),
                        ','.join(request.form.getlist('taste')), ','.join(request.form.getlist('allergies'))))
        conn.commit()
        conn.close()
        return redirect(url_for('meal_plan'))
    return render_template('shravani.html')

@app.route('/meal-plan')
def meal_plan():
    return render_template('mealplan.html')

@app.route('/get-meal-plan')
def get_meal_plan():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('home'))
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM user_profiles WHERE user_id=?", (user_id,))
    user_profile = cursor.fetchone()
    conn.close()
    if not user_profile:
        return redirect(url_for('onboarding'))
    
    meal_plan = generate_meal_plan(user_profile)
    return jsonify(meal_plan)

def generate_meal_plan(user_profile):
    prompt = f"Generate a 7-day meal plan for a {user_profile[2]} aged {user_profile[1]}, activity level {user_profile[5]}, goal {user_profile[6]}. Avoid {user_profile[9]}. Include clickable recipe links and nutritional information."
    response = openai.ChatCompletion.create(
        model="gemini-1",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
