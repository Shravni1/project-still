from flask import Flask, request, jsonify, redirect, url_for, render_template
from flask_sqlalchemy import SQLAlchemy
import bcrypt

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    age = db.Column(db.Integer)
    height = db.Column(db.Float)
    weight = db.Column(db.Float)
    gender = db.Column(db.String(10))
    activity_level = db.Column(db.String(20))
    fitness_goals = db.Column(db.String(200))
    health_conditions = db.Column(db.String(200))
    taste_preferences = db.Column(db.String(200))
    allergies = db.Column(db.String(200))

    def set_password(self, password):
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash.encode('utf-8'))

# Create database tables within the application context
with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.json
        user = User.query.filter_by(username=data['username']).first()
        if user and user.check_password(data['password']):
            return jsonify({'success': True, 'redirect': '/onboarding'})
        else:
            return jsonify({'success': False, 'message': 'Invalid username or password'})
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.json
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'success': False, 'message': 'Username already exists'})

        new_user = User(username=data['username'])
        new_user.set_password(data['password'])
        db.session.add(new_user)
        db.session.commit()
        return jsonify({'success': True, 'redirect': '/login'})
    return render_template('register.html')

@app.route('/onboarding', methods=['GET', 'POST'])
def onboarding():
    if request.method == 'POST':
        data = request.json
        user = User.query.filter_by(username=data['username']).first()
        if user:
            user.age = data['age']
            user.height = data['height']
            user.weight = data['weight']
            user.gender = data['gender']
            user.activity_level = data['activity_level']
            user.fitness_goals = data['fitness_goals']
            user.health_conditions = data['health_conditions']
            user.taste_preferences = data['taste_preferences']
            user.allergies = data['allergies']
            db.session.commit()
            return jsonify({'success': True, 'redirect': '/meal-plan'})
        else:
            return jsonify({'success': False, 'message': 'User not found'})
    return render_template('onboarding.html')

if __name__ == '__main__':
    app.run(debug=True)